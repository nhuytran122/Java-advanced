package TranNhuYthongkeModal;

public class TranNhuY_K45G_thongke {
	    private String maLoai;
	    private String tenLoai;
	    private int soLuongTin;
		public TranNhuY_K45G_thongke() {
			super();
			// TODO Auto-generated constructor stub
		}
		public TranNhuY_K45G_thongke(String maLoai, String tenLoai, int soLuongTin) {
			super();
			this.maLoai = maLoai;
			this.tenLoai = tenLoai;
			this.soLuongTin = soLuongTin;
		}
		public String getMaLoai() {
			return maLoai;
		}
		public void setMaLoai(String maLoai) {
			this.maLoai = maLoai;
		}
		public String getTenLoai() {
			return tenLoai;
		}
		public void setTenLoai(String tenLoai) {
			this.tenLoai = tenLoai;
		}
		public int getSoLuongTin() {
			return soLuongTin;
		}
		public void setSoLuongTin(int soLuongTin) {
			this.soLuongTin = soLuongTin;
		}
	    
	}
