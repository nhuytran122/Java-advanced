package TranNhuYthongkeModal;

import java.util.ArrayList;

public class TranNhuY_K45G_thongkebo {
	TranNhuY_K45G_thongkedao tkd = new TranNhuY_K45G_thongkedao();
	
	public ArrayList<TranNhuY_K45G_thongke> thongKeSoLuongTinTheoLoai() throws Exception {
		return tkd.thongKeSoLuongTinTheoLoai();
	}
}
